%average hourly data to daily data and convert from km/hr to m/s
%first copy km/hr data for each month into windkph vector
%then change mlength to number of days in the month
mlength=31;

windday=zeros(mlength,1);
for i=1:mlength
    windday(i)=mean(windkph(i:(i*24)))*0.2777778;
end