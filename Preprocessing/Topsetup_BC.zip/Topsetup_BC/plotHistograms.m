%go to Topsetup working directory
load wria1wi
load wria1of

[r,c]=size(WRIA1wi);
rm1=r-1;
plot(WRIA1wi(:,1),WRIA1wi(:,2),'r.','linewidth',3);hold on;
plot(wetness(:,1),wetness(:,2),'b.');hold on;
for i=2:46
    plot(wetness(:,(i*2-1)),wetness(:,(i*2)),'b.');hold on;
end
plot(WRIA1wi(:,1),WRIA1wi(:,2),'r','linewidth',2);hold on;

legend('WRIA1', 'BCupdate')
xlabel('wetness index (ln(area/slope) (m)')
ylabel('proportion')



figure
plot(WRIA1of(:,1)/1609.344,WRIA1of(:,2) ,'r','linewidth',3);hold on;
plot(overflowdisthists(:,1)/1609.344,overflowdisthists(:,2));hold on;
for i=2:46
    plot(overflowdisthists(:,(i*2-1))/1609.344,overflowdisthists(:,(i*2)));hold on;
end

legend('WRIA1', 'BCupdate')
xlabel('mile')
ylabel('probability')
